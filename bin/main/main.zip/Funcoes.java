package main;

public abstract class Funcoes {

	/**
	 * Insere dados na tabela.
	 */
	public static void inserir() {
	}

	/**
	 * Busca os dadis da tabela.
	 */
	public static void buscar() {
	}

	/**
	 * Altera os dados da tabela.
	 */
	public static void alterar() {
	}

	/**
	 * Exclui os dados na tabela.
	 */
	public static void excluir() {
	}
}
